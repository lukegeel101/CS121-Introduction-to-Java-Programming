  /*  Remember to import java.util.Random, otherwise you will get errors!  */

public class GuessingGame{

  /*  Here you will be creating your instance variables. When making instance variables, we think
   *  about what information we need to store between method calls. The info we will need to store
   *  is: 
   *
   *     1) the word the user is trying to guess. We will need a String instance variable called 'word' for that.
   *     2) the number of guesses the user has left. We will need an int called 'remainingGuesses' for that.
   *     3) we need to know if the word has been found. We will need a boolean called 'wordFound' for that.
   *     4) we need a random number generator. We will need a Random object called 'rand' for that.
   *
   *  Be sure to use the variable names EXACTLY as stated above or you won't pass many of the tests.
   */ 
   
   //TODO 1: Declare your instance variables here:


  /*  This is the first of two constructors. This one is used in the main method. We initialize each
   *  of our instance variables here. The player will start off with 10 guesses, the word obviously
   *  has not been found yet. You will need to initialize 'rand' before you can generate the word, and
   *  you will want to use the generateWord() helper method to initialize 'word' that way you don't have
   *  to write the same code a ton of times. 
   */
   public GuessingGame(){
   //TODO 3: Implement this method.
   }
   
  /*  This is our second constructor. There is only one real difference: in this one we take in an
   *  int which will act as the seed for our Random object. This is used for the tests.
   */
   public GuessingGame(int seed){
   //TODO 4: Implement this method.
   }
   
  /*  This is our play method. It takes in a String called 'str' and compares it to the word the
   *  player is trying to guess 'word'. It returns an int representing the number of letters which
   *  are in the exact same place in both words. For example, if the word to find were "WXYZ" play
   *  would return:
   *  
   *     1 on "WWWW" 
   *     2 on "WXWW" 
   *     2 on "WWWZ" 
   *     4 on "WXYZ" 
   *     4 on "wxyz" 
   *
   *  NOTE these values are ONLY for the example word "WXYZ" and will not be the same for your random
   *  word. Looping and using charAt() on the strings would be very useful here. Remember we do not
   *  care about upper/lower case here, so be sure to account for that.
   *
   *  We also want to decrement the user's remaining guesses, and in the event they guess the word
   *  we will also update wordFound to true before returning 4.
   */
   public int play(String str){
   //TODO 10: Implement this method.
   //TASK 1: Normalize string to uppercase
   
   //TASK 2: Decrement remainingGuesses and initialize a variable to count correctly guessed letters
   
   //TASK 3: Write a for loop to iterate over str
   
   //TASK 4: Write the if statement to check if the guessed letter matches the letter from the word
   
   //TASK 5: Write if statement to check if word was correctly guessed and change wordFound
   
   //TASK 6: Return count of correct guesses 
      return -1;
   }
   
  /*  isOver() simply returns true if the game is over, which is either when the player runs
   *  out of guesses or when they have found the correct word. It returns false otherwise.
   */
   public boolean isOver(){
   //TODO 5: Implement this method.
      return false;
   }
   
  /*  isWin() returns true if the player has correctly guessed the word and false otherwise.
   */
   public boolean isWin(){
   //TODO 6: Implement this method.
      return false;
   }
   
  /*  getRemainingGuesses() returns the number of remaining guesses the player has.
   */
   public int getRemainingGuesses(){
   //TODO 7: Implement this method.
      return -1;
   }
   
  /*  reset() returns nothing but resets the game. 'remainingGuesses' and 'wordFound' go back to 
   *  their default values and a new word is generated with generateWord().
   */
   public void reset(){
   //TODO 8: Implement this method.
   }
   
  /*  getWord() simply returns the word the user is attempting to guess. It is not tested,
   *  and is only used in the main method. 
   */
   public String getWord(){
   //TODO 9: Implement this method.
      return "";
   }
   
   /**********************************/
   /*         Helper Methods         */
   /**********************************/
   
  /*  A helper method is a private method which cannot be accessed outside of the file. Its
   *  sole purpose is to be used in other constructors/methods and simply 'helps' them do their
   *  job better. In our case, we need to generate a random word occasionally, so we make
   *  a helper method so that we don't have to write the same code repeatedly.
   *
   *  We will go about writing this by using our Random object. We will call nextInt(4) on our
   *  Random object a total of four times to generate four different ints. Specifying 4 in the
   *  method call forces it to generate an int between 0 and 4, including 0 but not including 4.
   *  The ints correspond to a letter to add to our word as such:
   *
   *     0: 'W'
   *     1: 'X'
   *     2: 'Y'
   *     3: 'Z'
   *
   *  We can build our String by starting with local variable which is an empty String ("") which we can 
   *  call retStr. Using String concatenation (+=), we can add letters to our String based on the int 
   *  generated. Once we have done this 4 times, we can return the String. We do not use any instance 
   *  variables in this method. It may be helpful to use a loop here.
   */
   private String generateWord(){
   //TODO 2: Implement this method.
   //TASK 1: Declare an empty string to hold the generated word
   
   //TASK 2: Write the for loop to generate each of the 4 letters
   
   //TASK 3: Use rand.nextInt() to generate a number between 0-3
   
   //TASK 4: Use if-else statements to concatenate W,X,Y, or Z to the word based on the random number
   
   //TASK 5: Return the generated string
      return "";
   }
   
}