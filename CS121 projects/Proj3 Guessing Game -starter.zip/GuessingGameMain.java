import java.util.*;

public class GuessingGameMain{

   public static void main(String[] args){
      
      //Here we declare and initialize our scanner
      Scanner scan = new Scanner(System.in);
      //Here we declare and initialize our "play again" boolean
      boolean again = true;
      
      System.out.println("Welcome to Guess Me!");
      System.out.println("A random word will be generated. It will be four letters long and\nconsist of the letters 'W', 'X', 'Y', and 'Z'. Your goal\nis to guess the word within the alloted guesses. Good luck!\n\n");
      GuessingGame game = new GuessingGame();
      //GuessingGame game = new GuessingGame(1234);

      while(again){
         while(!game.isOver()){
            System.out.println("You have " + game.getRemainingGuesses() + " guesses left.");
            System.out.println("Enter your guess:");
            String guess = scan.nextLine();
            int score = game.play(guess);
            System.out.println("There are " + score + " correct letter placements.");
            if(guess.length() != 4) {
               System.out.println("The length of the guess did not match the length of the word.");
            }
         }
         if(game.isWin()){
            System.out.println("Congrats!");
         } else {
            System.out.println("You lose! The word was: " + game.getWord());
         }
         System.out.println("Would you like to play again? y/n");
         if(Character.toLowerCase(scan.nextLine().charAt(0)) == 'n'){
            again = false;
         } else {
            game.reset();
         }
      }
      System.out.println("Goodbye!");
   }
}